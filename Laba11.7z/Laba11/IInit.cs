﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laba11
{
  
    
        public interface IInit // Интерфейс, который реализуют все классы: и классы животных, и людей
        {
            void Init();
            void Show();
            object Clone();
           

    }
    

}
