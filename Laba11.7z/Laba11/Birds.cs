﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Laba11
{
   
     
         class Birds : Animals
    {
        

            protected bool can_fly;
            protected bool can_swim;


            protected string wings;
            
            public override string GetType
            {
                get{return "bird";}
            }
            
            public bool Can_Fly
            {
                get { return can_fly; }
                set { can_fly = value; }
            }

            public bool Can_Swim
            {
                get { return can_swim; }
                set { can_swim = value; }
            }
        public Animals BaseAnimals
        { get
            {
                return new Animals(name, age, weight, oviparous);
            }
        }
        
        public string Wings
            {
                set
                {
                    if (value == string.Empty) wings = "совообразные";
                    else wings = value;
                }
                get { return wings; }
            }

            public Birds()
                : base()
            {
                wings = "совообразные";
                can_fly = true;
                can_swim = false;
            }

            public Birds(string name, int age, int weight, string wings, bool can_fly, bool can_swim)
                : base(name, age, weight, true)
            {
                Wings = wings;
                Can_Fly = can_fly;
                Can_Swim = can_swim;
            }

            public override void Init()
            {
                base.Init();
                Console.WriteLine("Введите тип крыльев");
                Wings = Console.ReadLine();
            }

            public override string ToString()
            {
                return base.ToString() + ", тип крыльев: " + wings + ", может летать: " + BoolToString(can_fly) +
                       ", может плавать: " + BoolToString(can_swim);
            }

            public override void Show()
            {

                Console.WriteLine(this.ToString());

            }

            public override object Clone()
            {
                
                Animals temp_animals = (Animals)base.Clone();
                Birds temp_birds = new Birds(temp_animals.Name, temp_animals.Age, temp_animals.Weight, this.Wings,
                    this.Can_Fly, this.Can_Swim);
                return temp_birds;
                
            }
        public override int GetHashCode()
        {
            return this.Name.GetHashCode() + this.age.GetHashCode() + this.weight.GetHashCode() +
            this.is_male.GetHashCode() + this.Oviparous.GetHashCode() + this.Can_Fly.GetHashCode() +
            this.Can_Swim.GetHashCode();
        }
        public override bool Equals(object obj)
            {
                if (obj is Birds)
                {
                    Birds m = (Birds)obj;
                    return Name == m.Name && Age == m.Age && Weight == m.Weight && Is_male == m.is_male && m.Oviparous == oviparous && m.Can_Fly == can_fly && m.Can_Swim == can_swim;

                }
                return false;

            }
            
            

        }
    }

