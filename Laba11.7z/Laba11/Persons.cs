﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laba11
{
 
    

        public class Persons : IInit, IAnimals
        {
            private string name;
            private int age;

            public string GetType
            {
                get{return "person";}
            }
            
            public string Name
            {
                set { name = value; }
                get { return name; }
            }

            public int Age
            {
                set
                {
                    if (value > 0) age = value;
                    else age = 0;
                }
                get { return age; }
            }

            public Persons(string name, int age)
            {
                this.Name = name;
                this.Age = age;
            }

            public Persons()
            {
                this.Name = "No Name";
                this.Age = 0;
            }

            public void Init()
            {
                string buf;
                Console.WriteLine("Введите имя");
                Name = Console.ReadLine();
                Console.WriteLine("Введите возраст");
                buf = Console.ReadLine();
                Age = Convert.ToInt32(buf);
            }

            public override string ToString()
            {
                string To_string = name + ", возраст: " + age;
                return To_string;
            }

            public void Show()
            {
                Console.WriteLine(this.ToString());
            }
            
            public virtual object Clone()
            {

                Persons temp_person = new Persons(this.Name, this.Age);
                return temp_person;

            }
        

        public virtual object ShallowCopy()
            {
                return (Persons)this.MemberwiseClone();
            }
        }
    }


