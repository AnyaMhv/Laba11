﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laba11
{
    
        public interface IAnimals : IInit // Интерфейс, который реализуют все классы животных. Наследуется от общего интерфейса Iinit, который реализует класс Persons
        {
        object Clone();
        object ShallowCopy();
            public string ToString();
            
            public string Name{get;}
            public int Age{get;}
            public string GetType {get;}
        }

    }


