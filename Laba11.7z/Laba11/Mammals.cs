﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Laba11
{
  
 
        public class Mammals : Animals
        {
            protected bool marsupials;

            public override string GetType
            {
                get{return "mammal";}
            }
            
            public Mammals(bool marsupials)
            {
                this.marsupials = marsupials;
            }

            public bool Marsupials
            {
                get { return marsupials; }
                set { marsupials = value; }
            }

            public Mammals()
                : base()
            {
                Marsupials = false;
                Oviparous = false;
            }

            public Mammals(string name, int age, int weight, bool marsupials, bool oviparous)
                : base(name, age, weight, oviparous)
            {
                this.Marsupials = marsupials;
            }

            public override void Init()
            {
                base.Init();
            }

            public override string ToString()
            {
                return base.ToString() + ", сумчатые: " + BoolToString(marsupials);
            }

            public override void Show()
            {
                Console.WriteLine(this.ToString());
            }

            public override object Clone()

            {
                Console.Clear();

                Animals temp_animals = (Animals)base.Clone();
                Mammals temp_mammals = new Mammals(temp_animals.Name, temp_animals.Age, temp_animals.Weight,
                    this.Marsupials, this.Oviparous);
                return temp_mammals;
                Console.ReadKey();
            }
            public override bool Equals(object obj)
            {
                if (obj is Mammals)
                {
                    Mammals m = (Mammals)obj;
                    return Name == m.Name && Age == m.Age && Weight == m.Weight && Is_male == m.is_male && m.Oviparous == oviparous && m.Marsupials == marsupials;

                }
                return false;

            }
            

        }
    }



