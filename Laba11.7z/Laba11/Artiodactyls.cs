﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Laba11
{
  
        public class Artiodactyls : Mammals, IAnimals, ICloneable
        {
            protected bool ruminant;
            protected string not_ruminant;
            protected int fingers_numbers;

            public override string GetType
            {
                get{return "artiodactyl";}
            }
            
            public bool Ruminant { get; set; }

            public int Fingers_numbers
            {
                set
                {
                    if (value is 2) fingers_numbers = value;
                    else if (value is 4) fingers_numbers = value;
                    else fingers_numbers = 4;

                }
                get
                {
                    return fingers_numbers;
                }
            }
            public Artiodactyls(string name, int age, int weight, int fingers_numbers, bool ruminant, bool marsupials)
               : base(name, age, weight, marsupials, false)
            {
                this.Fingers_numbers = fingers_numbers;
                this.Ruminant = ruminant;
                this.Marsupials = marsupials;
            }
            public override void Init()
            {
                base.Init();
                string buf;

                Console.WriteLine("введите количество пальцев на копытах");
                buf = Console.ReadLine();
                Fingers_numbers = Convert.ToInt32(buf);
            }

            public override string ToString()
            {
                return base.ToString() + ", жвачнное: " + BoolToString(ruminant) + ", количество пальцев на копытах: " + fingers_numbers;
            }
            public override void Show()
            {

                Console.WriteLine(this.ToString());

            }
            public override object Clone()
            {
                Console.Clear();
                Animals temp_animals = (Animals)base.Clone();
                Artiodactyls temp_artiodactyls = new Artiodactyls(temp_animals.Name, temp_animals.Age, temp_animals.Weight, this.fingers_numbers, this.ruminant, this.marsupials);
                return temp_artiodactyls;
                Console.ReadKey();
            }
            public override bool Equals(object obj)
            {
                if (obj is Artiodactyls)
                {
                    Artiodactyls m = (Artiodactyls)obj;
                    return Name == m.Name && Age == m.Age && Weight == m.Weight && Is_male == m.is_male && m.Oviparous == oviparous && m.Ruminant == ruminant && m.Fingers_numbers == fingers_numbers;

                }
                return false;

            }
            
            

        }
    }


