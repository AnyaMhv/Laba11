﻿using System;
using System.Collections.Generic;
using System.Diagnostics;


namespace Laba11
{
    class TestCollections
    {
        #region Массивы данных
        static string[] name =
        {
            "Артур", "Акела", "Игнат", "Лариса", "Искорка", "Арчибальд", "Снежок", "Пушок", "Джесси", "Джаспер",
            "Изабелла", "Кира", "Антон", "Клара", "Настя", "Рустам", "Пончик", "Одуванчик", "Глеб", "Имир", "Артемий", "Жана", "Кристоф"
        };


        static string[] wings =
            {"совообразные", "воробьинообразные", "гусеобразные", "аистообразные", "соколообразные"};

        #endregion

        List<Animals> list_of_animals;
        List<string> list_of_strings;
        Dictionary<Animals, Birds> dict_1;
        Dictionary<string, Birds> dict_2;
        public int size = 1000;
        static Random rnd = new Random();
        public TestCollections()
        {
            list_of_animals = new List<Animals>(size);
            list_of_strings = new List<string>(size);
            dict_1 = new Dictionary<Animals, Birds>(size);
            dict_2 = new Dictionary<string, Birds>(size);
        }
        #region Show
        public void Show_list_of_animals()
        {
            Console.WriteLine("Вывод list_of_animals");
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine(list_of_animals[i]);
            }
            Console.WriteLine();
        }
        public void Show_list_of_strings()
        {
            Console.WriteLine("Вывод list_of_strings");
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine(list_of_strings[i]);
            }
            Console.WriteLine();
        }
        public void Show_dict_1()
        {
            Console.WriteLine("Вывод dict_1");
            foreach (KeyValuePair<Animals, Birds> x in dict_1)
            {
                Console.Write(x.Key + ". " + x.Value);
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        public void Show_dict_2()
        {
            Console.WriteLine("Вывод dict_2");
            foreach (KeyValuePair<string, Birds> x in dict_2)
            {
                Console.Write(x.Key + ". " + x.Value);
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        public void Show()
        {
            if (size > 0)
            {
                list_of_animals = new List<Animals>(size);
                list_of_strings = new List<string>(size);
                dict_1 = new Dictionary<Animals, Birds>(size);
                dict_2 = new Dictionary<string, Birds>(size);
                for (int i = 0; i < size; i++)
                {
                    bool exists = true;
                    Birds birds;
                    do
                    {
    
                          
                        birds = new Birds(name[rnd.Next(0, 23)], rnd.Next(1, 40), rnd.Next(1, 10), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        if (dict_1.ContainsKey(birds.BaseAnimals) == false)
                        {
                            exists = false;
                        }
                    } while (exists);
                    Animals animals = birds.BaseAnimals;
                    list_of_animals.Add(animals);
                    list_of_strings.Add(animals.ToString());
                    dict_1.Add(animals, birds);
                    dict_2.Add(animals.ToString(), birds);
                }
                Show_list_of_animals();
                Show_list_of_strings();
                Show_dict_1();
                Show_dict_2();
            }
            else Console.WriteLine("Коллекции пустые!");
        }
        #endregion
        #region TimeSpan
        long Watch_for_list_of_animals(Animals elem)
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            if (list_of_animals.Contains(elem)) elem.Show();
            else Console.WriteLine("Элемент не найден!");
            sw.Stop();
            return sw.ElapsedTicks;
        }
        long Watch_for_list_of_strings(Animals elem)
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            if (list_of_strings.Contains(elem.ToString())) elem.Show();
            else Console.WriteLine("Элемент не найден!");
            sw.Stop();
            return sw.ElapsedTicks;
        }
        long Watch_for_dict_1_by_key(Animals elem)
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            if (dict_1.ContainsKey(elem)) elem.Show();
            else Console.WriteLine("Элемент не найден!");
            sw.Stop();
            return sw.ElapsedTicks;
        }
        long Watch_for_dict_1_by_value(Birds elem)
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            if (dict_1.ContainsValue(elem)) elem.Show();
            else Console.WriteLine("Элемент не найден!");
            sw.Stop();
            return sw.ElapsedTicks;
        }
        long Watch_for_dict_2(Animals elem)
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            if (dict_2.ContainsKey(elem.ToString())) elem.Show();
            else Console.WriteLine("Элемент не найден!");
            sw.Stop();
            return sw.ElapsedTicks;
        }
        #endregion
        #region Time_Research
        public void Time_Research_of_list_of_strings(Animals first_elem, Animals middle_elem, Animals last_elem, Animals out_elem)
        {
            long time = Watch_for_list_of_strings(first_elem);
            Console.WriteLine("Время, необходимое для поиска первого элемента в list_of_strings: " + time);
            time = Watch_for_list_of_strings(middle_elem);
            Console.WriteLine("Время, необходимое для поиска среднего элемента в list_of_strings: " + time);
            time = Watch_for_list_of_strings(last_elem);
            Console.WriteLine("Время, необходимое для поиска последнего элемента в list_of_strings: " + time);
            time = Watch_for_list_of_strings(out_elem);
            Console.WriteLine("Время, необходимое для поиска элемента вне list_of_strings: " + time);
            Console.WriteLine();
        }
        public void Time_Research_of_list_of_persons(Animals first_elem, Animals middle_elem, Animals last_elem, Animals out_elem)
        {
            long time = Watch_for_list_of_animals(first_elem);
            Console.WriteLine("Время, необходимое для поиска первого элемента в list_of_animals: " + time);
            time = Watch_for_list_of_animals(middle_elem);
            Console.WriteLine("Время, необходимое для поиска среднего элемента в list_of_animals: " + time);
            time = Watch_for_list_of_animals(last_elem);
            Console.WriteLine("Время, необходимое для поиска последнего элемента в list_of_animals: " + time);
            time = Watch_for_list_of_animals(out_elem);
            Console.WriteLine("Время, необходимое для поиска элемента вне list_of_animals: " + time);
            Console.WriteLine();
        }
        public void Time_Research_of_dict_1_by_key(Animals first_elem, Animals middle_elem, Animals last_elem, Animals out_elem)
        {
            long time = Watch_for_dict_1_by_key(first_elem);
            Console.WriteLine("Время, необходимое для поиска первого элемента по ключу в dict_1: " + time);
            time = Watch_for_dict_1_by_key(middle_elem);
            Console.WriteLine("Время, необходимое для поиска среднего элемента по ключу в dict_1: " + time);
            time = Watch_for_dict_1_by_key(last_elem);
            Console.WriteLine("Время, необходимое для поиска последнего элемента по ключу в dict_1: " + time);
            time = Watch_for_dict_1_by_key(out_elem);
            Console.WriteLine("Время, необходимое для поиска элемента по ключу вне dict_1: " + time);
            Console.WriteLine();
        }
        public void Time_Research_of_dict_2(Animals first_elem, Animals middle_elem, Animals last_elem, Animals out_elem)
        {
            long time = Watch_for_dict_2(first_elem);
            Console.WriteLine("Время, необходимое для поиска первого элемента по ключу в dict_2: " + time);
            time = Watch_for_dict_2(middle_elem);
            Console.WriteLine("Время, необходимое для поиска среднего элемента по ключу в dict_2: " + time);
            time = Watch_for_dict_2(last_elem);
            Console.WriteLine("Время, необходимое для поиска последнего элемента по ключу в dict_2: " + time);
            time = Watch_for_dict_2(out_elem);
            Console.WriteLine("Время, необходимое для поиска элемента по ключу вне dict_2: " + time);
            Console.WriteLine();
        }
        public void Time_Research_of_dict_1_by_value(Birds first_elem, Birds middle_elem, Birds last_elem, Birds out_elem)
        {
            long time = Watch_for_dict_1_by_value(first_elem);
            Console.WriteLine("Время, необходимое для поиска первого элемента по значению в dict_1: " + time);
            time = Watch_for_dict_1_by_value(middle_elem);
            Console.WriteLine("Время, необходимое для поиска среднего элемента по значению в dict_1: " + time);
            time = Watch_for_dict_1_by_value(last_elem);
            Console.WriteLine("Время, необходимое для поиска последнего элемента по значению в dict_1: " + time);
            time = Watch_for_dict_1_by_value(out_elem);
            Console.WriteLine("Время, необходимое для поиска элемента по значению вне dict_1: " + time);
            Console.WriteLine();
        }
        public void Time_Research()
        {
            Animals first_elem = (Animals) list_of_animals[0].Clone();
            Animals middle_elem = (Animals)list_of_animals[size / 2].Clone();
            Animals last_elem = (Animals)list_of_animals[size - 1].Clone();
            Animals out_elem = new Animals(name:"a",age: 5,weight:18, oviparous:false);
            Birds first_elem_1 = (Birds)dict_1[first_elem].Clone();
            Birds middle_elem_1 = (Birds)dict_1[middle_elem].Clone();
            Birds last_elem_1 = (Birds)dict_1[last_elem].Clone();
            Birds out_elem_1 = new Birds(name: "a", age: 5, weight: 1,wings: "воробьинообразные",can_fly:false,can_swim:true);
            Time_Research_of_list_of_persons(first_elem, middle_elem, last_elem, out_elem);
            Time_Research_of_list_of_strings(first_elem, middle_elem, last_elem, out_elem);
            Time_Research_of_dict_1_by_key(first_elem, middle_elem, last_elem, out_elem);
            Time_Research_of_dict_2(first_elem, middle_elem, last_elem, out_elem);
            Time_Research_of_dict_1_by_value(first_elem_1, middle_elem_1, last_elem_1, out_elem_1);
        }
        #endregion
        #region Adding
        public void Adding()
        {
            Birds birds;
            do
            {
                birds = new Birds(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 2), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
            } 
            while (dict_1.ContainsKey(birds.BaseAnimals));
            Console.WriteLine("Добавление случайного элемента в конец: " + birds.ToString());
            Animals animals = birds.BaseAnimals;
            size += 1;
            list_of_animals.Add(animals);
            list_of_strings.Add(birds.ToString());
            dict_1.Add(animals, birds);
            dict_2.Add(animals.ToString(), birds);
            Show();
        }
        #endregion
        #region Removing
        public void Removing()
        {
            Animals animals = list_of_animals[rnd.Next(list_of_animals.Count)];
            Console.WriteLine("Удаление случайного элемента: " + animals.ToString());
            size--;
            list_of_animals.Remove(animals);
            list_of_strings.Remove(animals.ToString());
            dict_1.Remove(animals);
            dict_2.Remove(animals.ToString());
            Show();
        }
        #endregion
    }
}

   
