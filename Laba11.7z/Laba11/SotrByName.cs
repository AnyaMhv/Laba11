﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laba11
{
    
        public class SortByName : IComparer<object>
        {
            public int Compare(object ob1, object ob2)
            {
                Animals animals_1 = (Animals)ob1;
                Animals animals_2 = (Animals)ob2;
                int result = String.Compare(animals_1.Name, animals_2.Name);
                if (result == 0)
                {
                    if (animals_1.Age < animals_2.Age) result = -1;
                    else if (animals_1.Age < animals_2.Age) result = 1;
                }
                return result;
            }
        }


    }


