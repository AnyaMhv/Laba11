﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laba11
{
    
    public class Animals : IAnimals, IComparable, ICloneable
    {
        protected string name;
        protected int age;
        protected int weight;
        protected bool is_male;
        protected bool oviparous;

        public virtual string GetType
        {
            get{return "animal";}
        }
        
        public string Name
        {
            set { name = value; }
            get { return name; }
        }

        public int Age
        {
            set
            {
                if (value > 0) age = value;
                else age = 0;
            }
            get { return age; }
        }

        public int Weight
        {
            set
            {
                if (value > 0) weight = value;
                else weight = 0;
            }
            get { return weight; }
        }

        public bool Is_male
        {
            set
            {
                char a = this.name[this.name.Length - 1];
                if (a == 'а')
                    this.is_male = false;
                else this.is_male = true;
            }
            get { return this.is_male; }
        }

        public bool Oviparous
        {
            get { return oviparous; }
            set { oviparous = value; }
        }

        public Animals()
        {
            name = "Артур";
            age = 5;
            weight = 1;
            is_male = Is_male;
            Oviparous = false;
        }

        public Animals(string name, int age, int weight, bool oviparous)
        {
            Name = name;
            Age = age;
            Weight = weight;
            Is_male = this.is_male;
            Oviparous = oviparous;
        }

        public virtual void Init()
        {
            string buf;
            string buf1;
            Console.WriteLine("Введите имя");
            Name = Console.ReadLine();
            Console.WriteLine("Введите возраст");
            buf = Console.ReadLine();
            Age = Convert.ToInt32(buf);
            Console.WriteLine("Введите вес");
            buf1 = Console.ReadLine();
            Weight = Convert.ToInt32(buf1);
        }

        private string SexToString()
        {
            return is_male ? "мужской" : "женский";
        }

        protected string BoolToString(bool value)
        {
            return value ? "да" : "нет";
        }

        public override string ToString()
        {
            string To_string = name + ", возраст: " + age + ", вес(кг): " + weight + ", пол: " + SexToString() +
                               ", яйценосные: " + BoolToString(oviparous);
            return To_string;
        }

        public virtual void Show()
        {

            Console.WriteLine(this.ToString());

        }

        public int CompareTo(object ob1)
        {
            Animals animals_2 = (Animals)ob1;
            int result = String.Compare(this.Name, animals_2.Name);
            if (result == 0)
            {
                if (this.Age < animals_2.Age) result = -1;
                else if (this.Age > animals_2.Age) result = 1;
            }


            return result;
        }

        public virtual object Clone()
        {

            Animals temp_animals = new Animals(this.Name, this.Age, this.Weight, this.Oviparous);
            return temp_animals;

        }
        public override int GetHashCode()
        {
            return this.Name.GetHashCode() + this.age.GetHashCode() + this.weight.GetHashCode() +
            this.is_male.GetHashCode() + this.Oviparous.GetHashCode();
        }

        public virtual object ShallowCopy()
        {
            return (Animals)this.MemberwiseClone();
        }
        public override bool Equals(object obj)
        {
            if (obj is Animals)
            {
                Animals m = (Animals)obj;
                return Name == m.Name && Age == m.Age && Weight == m.Weight && Is_male == m.is_male && m.Oviparous == oviparous;

            }
            return false;

        }
        

    }
}

