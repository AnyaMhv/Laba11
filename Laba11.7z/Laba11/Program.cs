﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Laba11
{
    public class Program
    {



        static Random rnd = new Random();

        private static bool was_cloned_list = false;

        private static bool was_cloned_dict = false;

        private static SortedList cloned_sorted_list = new SortedList();

        private static SortedDictionary<string, IAnimals> cloned_sorted_dict = new SortedDictionary<string, IAnimals>();

        #region Массивы данных

        static string[] name =
        {
            "Артур", "Акела", "Игнат", "Лариса", "Искорка", "Арчибальд", "Снежок", "Пушок", "Джесси", "Джаспер",
            "Изабелла", "Кира"
        };

        static string[] person_name =
        {
            "Иван", "Ольга", "Мария", "Анастасия", "Петр", "Игорь", "Александр", "Юлия", "Дмитрий", "Анна"
        }; // Массив имен для людей

        static string[] wings =
            {"совообразные", "воробьинообразные", "гусеобразные", "аистообразные", "соколообразные"};

        #endregion



        static SortedList CloneSortedList(SortedList sl)
        {
            SortedList result = new SortedList();
            foreach (DictionaryEntry o in sl)
            {
                result.Add(
                    o.Value.ToString(),
                    (o.Value as IInit).Clone()
                    );
            }
            return result;
        }


        static SortedDictionary<string, IAnimals> CloneSortedDict(SortedDictionary<string, IAnimals> sl)
        {
            SortedDictionary<string, IAnimals> result = new SortedDictionary<string, IAnimals>();
            foreach (var o in sl)
            {
                result.Add(
                    o.Value.Clone().ToString(),
                    o.Value.Clone() as IAnimals
                );
            }
            return result;
        }



        public static void Select_Menu_Option(int currentSelection, string[] options)
        {
            Console.Clear();
            for (int i = 0; i < options.Length; i++)
            {
                if (i != currentSelection)
                {
                    Console.WriteLine(options[i]);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(options[i]);
                    Console.ResetColor();
                }
            }
        }
        public static int Menu(string[] options)
        {
            const int optionsPerLine = 1;

            int currentSelection = 0;

            ConsoleKey key;

            Console.CursorVisible = false;

            Select_Menu_Option(0, options);
            do
            {
                key = Console.ReadKey().Key;

                switch (key)
                {
                    case ConsoleKey.UpArrow:
                        {
                            if (currentSelection - optionsPerLine >= 0)
                                currentSelection -= optionsPerLine;
                            else
                            {
                                currentSelection = options.Length - 1;
                            }

                            break;
                        }
                    case ConsoleKey.DownArrow:
                        {
                            if (currentSelection + optionsPerLine >= options.Length)
                                currentSelection = 0;
                            else
                            {
                                currentSelection += optionsPerLine;
                            }

                            break;
                        }
                }

                Select_Menu_Option(currentSelection, options);
            } while (key != ConsoleKey.Enter);

            return currentSelection + 1;
        }

        static void Сlose(ref bool Exit)
        {
            Exit = false;
        }

        static void Main(string[] args)
        {
            bool Exit = true;

            while (Exit)
            {
                string[] options =
                {
                    "1. Работа с коллекцией Sortedlist",
                    "2. Работа коллекцией  sorteddisctionary<K,T>",
                    "3.Работа с коллекцией MyList<T>",
                    "4.Выход"

                }; // Массив из строк меню
                int PointInMenu = Menu(options);
                switch (PointInMenu)
                {
                    case 1:
                        Part1Menu(args);
                        break;
                    case 2:
                        Part2Menu(args);
                        break;
                    case 3:
                        Part3Menu(args);
                        break;
                    case 4:
                        Сlose(ref Exit);
                        break;
                }
            }
        }

        static void Part1Menu(string[] args)
        {
            SortedList animals = new SortedList();
            bool Exit = true;
            int result = 0;

            while (Exit)
            {
                string[] options =
                {
                    "1. Добавить в коллекцию 10 элементов",
                    "2. Очистить коллекцию",
                    "3.Удалить последний элемент",
                    "4.Добавить элемент в конец",
                    "5.Найти всех артиодактилей",
                    "6.Найти всех млекопитающих за исключением людей",
                    "7.Найти всех существ младше 10 лет",
                    "8.Напечатать все элементы",
                    "9.Клонировать коллекцию",
                    "10.Найти элемент по его имени",
                    "11.Выход"


                }; // Массив из строк меню
                int PointInMenu = Menu(options);
                switch (PointInMenu)
                {
                    case 1:
                        Console.Clear();
                        for (int i = 0; i < 10; i++)
                        {


                            Animals defaultAnimal = new Animals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), Convert.ToBoolean(rnd.Next(2)));
                            Birds bird = new Birds(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 2), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Mammals mammal = new Mammals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 40), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Artiodactyls artiodactyl = new Artiodactyls(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), rnd.Next(2, 4), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Persons person = new Persons(person_name[rnd.Next(0, 9)], rnd.Next(1, 60));
                            IAnimals animalToAdd = (new IAnimals[] { defaultAnimal, bird, mammal, artiodactyl, person })[rnd.Next(1, 5)];
                            animals.Add(animalToAdd.ToString(), animalToAdd);
                            Console.WriteLine("добавлен элемент типа " + animalToAdd.GetType + " " + animalToAdd.ToString());

                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.Clear();
                        animals.Clear();
                        Console.WriteLine("коллекция очищена");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        if (animals.Count == 0)
                        {

                            Console.WriteLine("коллекция пуста");
                            Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                            Console.ReadKey();
                            break;
                        }
                        Console.WriteLine("убран элемент " + animals.GetByIndex(animals.Count - 1).ToString());
                        animals.Remove(animals.GetByIndex(animals.Count - 1).ToString());
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();


                        Animals defaultAnimal_ = new Animals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), Convert.ToBoolean(rnd.Next(2)));
                        Birds bird_ = new Birds(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 2), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Mammals mammal_ = new Mammals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 40), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Artiodactyls artiodactyl_ = new Artiodactyls(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), rnd.Next(2, 4), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Persons person_ = new Persons(person_name[rnd.Next(0, 9)], rnd.Next(1, 60));
                        IAnimals animalToAdd_ = (new IAnimals[] { defaultAnimal_, bird_, mammal_, artiodactyl_, person_ })[rnd.Next(1, 6)];
                        animals.Add(animalToAdd_.ToString(), animalToAdd_);
                        Console.WriteLine("добавлен элемент типа " + animalToAdd_.GetType + " " + animalToAdd_.ToString());

                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 5: //запрос 1: элементы определённого типа (артиодактиль)
                        Console.Clear();
                        foreach (DictionaryEntry animal in animals)
                        {
                            if ((animal.Value as IAnimals).GetType == "artiodactyl") { result++; }

                        }
                        Console.WriteLine("в коллекции " + result + " артиодактилей");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 6: //запрос 2: печать всех маммалов
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (DictionaryEntry animal in animals)
                            {
                                if ((animal.Value as Artiodactyls == null) & (animal.Value is Mammals)) { (animal.Value as Mammals).Show(); }

                            }
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 7: //запрос 3: подсчёт особей, которым меньше 10 лет
                        Console.Clear();
                        foreach (DictionaryEntry animal in animals)
                        {
                            if ((animal.Value as IAnimals).Age < 10) { result++; }
                        }
                        Console.WriteLine("в коллекции " + result + " особей младше 10 лет");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 8: //перебор
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (DictionaryEntry animal in animals)
                            {
                                Console.WriteLine("тип элемента: " + (animal.Value as IAnimals).GetType + " " + animal.Key);

                            }
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 9: //клонирование
                        Console.Clear();
                        if (!was_cloned_list)
                        {
                            if (animals.Count == 0)
                            {
                                Console.WriteLine("коллекция пуста");
                            }
                            else
                            {

                                cloned_sorted_list = CloneSortedList(animals);
                                was_cloned_list = true;
                            }
                        }
                        foreach (DictionaryEntry animal in cloned_sorted_list)
                        {
                            var entry_value = animal.Value as IInit;
                            entry_value.Show();
                        }

                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 10: //поиск по имени
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            Console.WriteLine("введите имя экземпляра, который хотите найти");
                            string input = Console.ReadLine().Trim().ToLower();
                            foreach (DictionaryEntry animal in animals)
                            {
                                if ((animal.Value as IAnimals).Name.ToLower() == input) { (animal.Value as IAnimals).Show(); break; }
                                Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                                Console.ReadKey();
                            }
                            Console.WriteLine("такого элемента в коллекции нет");
                        }

                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 11:
                        Сlose(ref Exit);
                        break;
                }
            }
        }

        static void Part2Menu(string[] args)
        {
            SortedDictionary<string, IAnimals> animals = new SortedDictionary<string, IAnimals>();
            bool Exit = true;
            int result = 0;

            while (Exit)
            {
                string[] options =
                {
                    "1. Добавить в коллекцию 10 элементов",
                    "2. Очистить коллекцию",
                    "3.Удалить последний элемент",
                    "4.Добавить элемент в конец",
                    "5.Найти всех артиодактилей",
                    "6.Найти всех млекопитающих за исключением людей",
                    "7.Найти всех существ младше 10 лет",
                    "8.Напечатать все элементы",
                    "9.Клонировать коллекцию",
                    "10.Найти элемент по его имени",
                    "11.Выход"


                }; // Массив из строк меню
                int PointInMenu = Menu(options);
                switch (PointInMenu)
                {
                    case 1: //добавить 10 элементов
                        Console.Clear();
                        for (int i = 0; i < 10; i++)
                        {

                            Animals defaultAnimal = new Animals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), Convert.ToBoolean(rnd.Next(2)));
                            Birds bird = new Birds(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 2), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Mammals mammal = new Mammals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 40), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Artiodactyls artiodactyl = new Artiodactyls(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), rnd.Next(2, 4), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                            Persons person = new Persons(person_name[rnd.Next(0, 9)], rnd.Next(1, 60));
                            IAnimals animalToAdd = (new IAnimals[] { defaultAnimal, bird, mammal, artiodactyl, person })[rnd.Next(1, 5)];
                            animals.Add(animalToAdd.ToString(), animalToAdd);
                            Console.WriteLine("добавлен элемент типа " + animalToAdd.GetType + " " + animalToAdd.ToString());


                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 2: //очистить
                        Console.Clear();
                        animals.Clear();
                        Console.WriteLine("коллекция очищена");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 3: //удалить последний
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                            Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                            Console.ReadKey();
                            break;
                        }
                        Console.WriteLine("убран элемент " + animals.Values.Last().ToString());
                        animals.Remove(animals.Values.Last().ToString());
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 4: //добавить элемент
                        Console.Clear();
                        Animals defaultAnimal_ = new Animals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), Convert.ToBoolean(rnd.Next(2)));
                        Birds bird_ = new Birds(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 2), wings[rnd.Next(0, 5)], Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Mammals mammal_ = new Mammals(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 40), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Artiodactyls artiodactyl_ = new Artiodactyls(name[rnd.Next(0, 12)], rnd.Next(1, 18), rnd.Next(1, 18), rnd.Next(2, 4), Convert.ToBoolean(rnd.Next(2)), Convert.ToBoolean(rnd.Next(2)));
                        Persons person_ = new Persons(person_name[rnd.Next(0, 9)], rnd.Next(1, 60));
                        IAnimals animalToAdd_ = (new IAnimals[] { defaultAnimal_, bird_, mammal_, artiodactyl_, person_ })[rnd.Next(1, 6)];
                        animals.Add(animalToAdd_.ToString(), animalToAdd_);
                        Console.WriteLine("добавлен элемент типа " + animalToAdd_.GetType + " " + animalToAdd_.ToString());
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 5: //запрос 1: элементы определённого типа (артиодактиль)
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (var animal in animals)
                            {
                                if (animal.Value.GetType == "artiodactyl") { result++; }

                            }
                            Console.WriteLine("в коллекции " + result + " артиодактилей");
                        }

                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 6: //запрос 2: печать всех маммалов
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (var animal in animals)
                            {
                                if ((animal.Value as Artiodactyls == null) & (animal.Value is Mammals)) { (animal.Value as Mammals).Show(); }

                            }
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 7: //запрос 3: подсчёт особей, которым меньше 10 лет
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (var animal in animals)
                            {
                                if (animal.Value.Age < 10) { result++; }
                                Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                                Console.ReadKey();
                            }
                            Console.WriteLine("в коллекции " + result + " особей младше 10 лет");
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 8: //перебор
                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            foreach (var animal in animals)
                            {
                                Console.WriteLine("тип элемента: " + animal.Value.GetType + " " + animal.Key);

                            }
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 9: //клонирование
                        Console.Clear();
                        if (!was_cloned_dict)
                        {
                            if (animals.Count == 0)
                            {
                                Console.WriteLine("коллекция пуста");
                            }
                            else
                            {

                                cloned_sorted_dict = CloneSortedDict(animals);
                                was_cloned_dict = true;
                            }
                        }
                        foreach (var animal in cloned_sorted_dict)
                        {
                            var entry_value = animal.Value;
                            entry_value.Show();
                        }
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 10: //поиск по имени

                        Console.Clear();
                        if (animals.Count == 0)
                        {
                            Console.WriteLine("коллекция пуста");
                        }
                        else
                        {
                            Console.WriteLine("введите имя экземпляра, который хотите найти");
                            string input = Console.ReadLine().Trim().ToLower();
                            foreach (var animal in animals)
                            {
                                if (animal.Value.Name.ToLower() == input) { animal.Value.Show(); break; }
                                else Console.WriteLine("такого элемента в коллекции нет");
                            }

                        }

                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 11:


                        Сlose(ref Exit);
                        break;
                }
            }
        }



        static void Part3Menu(string[] args)
        {
            TestCollections testCollections = new TestCollections();
            bool Exit = true;

            while (Exit)
            {
                string[] options =
                {
                    "1.  Сгенерировать элементы коллекций",
                    "2.  Определить, сколько времени требуется для поиска элементов в каждой коллекции",
                    "3.Добавить случайный элемент в конец каждой коллекции",
                    "4.Удалить случайный элемент из каждой коллекции",
                    "5.Выход"

                }; // Массив из строк меню
                int PointInMenu = Menu(options);
                switch (PointInMenu)
                {
                    case 1:
                        Console.Clear();
                        testCollections.Show();
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.Clear();
                        if (testCollections.size > 0)
                            testCollections.Time_Research();
                        else Console.WriteLine("Коллекции пустые!");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        testCollections.Adding();
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;

                    case 4:
                        Console.Clear();
                        if (testCollections.size > 0)
                            testCollections.Removing();
                        else Console.WriteLine("Коллекции пустые!");
                        Console.WriteLine("Нажмите на любую клавишу, чтобы перейти в меню");
                        Console.ReadKey();
                        break;
                    case 5:
                        Сlose(ref Exit);
                        break;
                }
            }
        }
    }
}
